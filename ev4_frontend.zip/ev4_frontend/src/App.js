// src/App.js
import React, { useState, useEffect } from 'react';
import Note from './Note';
import './App.css';

function App() {
  const [notes, setNotes] = useState(() => {
    const savedNotes = localStorage.getItem('notes');
    return savedNotes ? JSON.parse(savedNotes) : [];
  });
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [important, setImportant] = useState(false);
  const [errors, setErrors] = useState({ title: '', description: '' });

  useEffect(() => {
    localStorage.setItem('notes', JSON.stringify(notes));
  }, [notes]);

  const addNote = () => {
    let newErrors = { description: '' };
    let valid = true;

    if (description.trim() === '') {
      newErrors.description = 'La descripción es obligatoria';
      valid = false;
    }

    if (!valid) {
      setErrors(newErrors);
      return;
    }

    const newNote = {
      id: Date.now(),
      title,
      description,
      important,
      rotate: Math.random() * 10 - 7 // añadir rotación aleatoria
    };

    setNotes([...notes, newNote]);
    setTitle('');
    setDescription('');
    setImportant(false);
    setErrors({ title: '', description: '' });
  };

  const deleteNote = (id) => {
    setNotes(notes.filter((note) => note.id !== id));
  };

  return (
    <div className="App">
      <h1>Mis Notas Adhesivas!</h1>
      <div className="note-form-container">
        <div className="note-form">
          <label>
            Título:
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
            {errors.title && <div className="error-message">{errors.title}</div>}
          </label>
          <label>
            Descripción:
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
            {errors.description && <div className="error-message">{errors.description}</div>}
          </label>
          <label>
            Importante:
            <input
              type="checkbox"
              checked={important}
              onChange={(e) => setImportant(e.target.checked)}
            />
          </label>
          <button onClick={addNote}>AGREGAR</button>
        </div>
      </div>
      <div className="notes-container">
        {notes.map((note) => (
          <Note key={note.id} note={note} onDelete={deleteNote} />
        ))}
      </div>
    </div>
  );
}

export default App;